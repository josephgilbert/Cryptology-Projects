package shiftregisterpackage;

import java.util.List;

/*
 * This class does most of the dirty work.
 * It simulates encryption/decryption using an LFSR to generate a key stream of bits
 * based on a hardcoded seed.
 * The feedback bits are given in a list, which is created in the LFSRMain
 * classes' main method. 
 * Created by Joe Gilbert, 2018. 
 */
public class ShiftRegister {
	    
	    char[] seedArray   = { '0','1','0','0','1','0','0','1' };
		int sizeOfRegister;
		int numOfFeedBackBits;
		boolean[] listOfBits;
	    
	    
		String seed = "01001001";
		
	    public boolean[] register;
		List<Integer> feedBackList; 
	    
	    //Creates a new ShiftRegister class instance when called.
	    //listOfBits is the stream of 0s and 1s input received from the read file.
	    public ShiftRegister( List<Integer> feedBackList,
	    		int sizeOfRegister, boolean[] listOfBits) {
	    	
	    	this.sizeOfRegister = sizeOfRegister;
			this.feedBackList = feedBackList;
			this.listOfBits = listOfBits;
			this.register = new boolean[8];
			
	    }
	    
	    //Encrypts the stream from the file by XORing it with the key stream. 
	    public boolean[] encryptInput(boolean[] key, boolean[] input) {
	    	boolean[] results = new boolean[input.length];
	    	int x = 0;
	    	for (int i = 0; i < key.length; i++) {
	    		results[i]=xorGate(key[x],input[x]);
	    		x++;
	    	}
	    	return results;
	    		
	    }
	    
	    //Initializes the register with the seed.
	    public void initializer() {
	    	
	    	char[] inputArray = seedArray;
	    	
	    	int bIdx = 0;
	    	for (int i = inputArray.length -1; i >0; i--) {
	    		
				if (inputArray[i] == '1') {
					register[bIdx] = true;
				}
				else if (inputArray[i] == '0') {
					register[bIdx] = false;
				}
				bIdx++;
			}
	    }
	    
	    //Converts the encrypted bits to a string.
	    public String boolToString(boolean[] input) {
	    	char[] encryptedBits = new char[input.length];
	    	String str = "";
	    	int cIdx = input.length-1;
	    	
			for (int i = 0; i < input.length; i++) {
				if (input[i] == true) {
					
					encryptedBits[cIdx] = '1';
				}
				else if (input[i] == false) {
					encryptedBits[cIdx] = '0';
				}
				cIdx--;
			}
			for (int i = 0; i < encryptedBits.length; i++) {
				str = str + encryptedBits[i];
			}
			return (str);
	    }
	    
	    //Convenient method for converting boolean arrays to char arrays.
	    public char[] boolToChar(boolean[] bolly) {
	    	char[] bolmanFreedon = new char[bolly.length];
	    	for (int i = 0; i<bolly.length; i++) {
	    		if (bolly[i] == true) {
	    			bolmanFreedon[i] = '1';
	    		} else if (bolly[i] == false){
	    			bolmanFreedon[i] = '0';
	    		}
	        }
	    	return bolmanFreedon;
	    }
	    
	    //Returns a standard string.
	    public String boolToStringForward(boolean[] input) {
	    	char[] encryptedBits = new char[input.length];
	    	String str = "";
	    	
	    	
			for (int i = 0; i < input.length; i++) {
				if (input[i] == true) {
					
					encryptedBits[i] = '1';
				}
				else if (input[i] == false) {
					encryptedBits[i] = '0';
				}
				
			}
			for (int i = 0; i < encryptedBits.length; i++) {
				str = str + encryptedBits[i];
			}
			return (str);
	    }
	    
	    //Converts char arrays to boolean arrays.
	    public boolean[] charToBoolean(char[] input) {
	    	boolean[] encryptedBits = new boolean[input.length];
			for (int i = 0; i < input.length; i++) {
				if (input[i] == '1') {
					encryptedBits[i] = true;
				}
				else if (input[i] == '0') {
					encryptedBits[i] = false;
				}
			}
			
			return encryptedBits;
	    }
	    
	    //Simple method to XOR 2 bits.
	    public boolean xorGate(boolean a, boolean b) {
			return (a ^ b);
		}
	    
	    //Performs a 1-bit shift on the register.
	    public boolean step() {
	        boolean xor = xorGate(register[feedBackList.get(0)], register[feedBackList.get(1)]);
	    	
	        for (int i = register.length-1; i > 0; i--) {
				register[i]=register[i-1];
			}
	        register[0] = xor;
	        return xor;
	    }
	    
	    //Generates the key to be XOR'd with the stream read from the file.
	    public boolean[] generateKey(int lengthOfInput, boolean[] binSeed) {
	    	boolean[] encryptionKey = new boolean[lengthOfInput];
	    	for(int i = 0; i < binSeed.length; i++) {
	    		encryptionKey[i] = binSeed[i]; 
	    	}
	    	for(int i = binSeed.length+1; i < lengthOfInput; i++) {
	    		encryptionKey[i] = step(); 
	    	}
	    	return encryptionKey;
	    }
	    
	    //Generates a stream of bits used to encrypt the input data stream.
	    public int generate(int k) {
	    	int total = 0;
	    	int bitToAdd=0;
	    	for (int i = 0; i < k; i++) {
	    	    boolean extractedBit = step();
	    	    if (extractedBit == true) {
	    	    	bitToAdd = 1;
	    	    } else if (extractedBit == false){
	    	    	bitToAdd = 0;
	    	    }
	    	    total = (total * 2) + bitToAdd; 
	    	}
	    	return total;
	    }
	    
	    
		
	    
}
