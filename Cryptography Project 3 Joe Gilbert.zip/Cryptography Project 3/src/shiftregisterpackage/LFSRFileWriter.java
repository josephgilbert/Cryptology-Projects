package shiftregisterpackage;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


//This is a class built solely for reading and writing to files.
//IMPORTANT: YOU MAY NEED TO RESPECIFY THE inFilePath and outFilePath VARIABLES TO MATCH
//YOUR USERNAME INSTEAD OF Joe.  
//Created by Joe Gilbert 2018.
public class LFSRFileWriter {
	String materialLibrary;
	
	String group;
	String mtlAux;
	String name;
	String inFilePath = "C:\\Users\\Joe\\eclipse-workspace\\Cryptography Project 3\\src\\shiftregisterpackage\\inputFileOfProject.txt";
	String outFilePath = "C:\\Users\\Joe\\eclipse-workspace\\Cryptography Project 3\\src\\shiftregisterpackage\\outputFileOfProject.txt";

	public LFSRFileWriter(String name) {
		this.name = name;
		
	}
	
	//Method to write the encrypted data (in an array of bytes) to the output file.
	public void writeToTheFile(char[] inArray) throws IOException {
		File outputFile = new File(outFilePath);
		String arrayStr = new String(inArray);
		
		String outLine = "";
		
		for (int i = 0; i < inArray.length; i+=8) {
			String deez = arrayStr.substring(i,i+8);
			int nunz = Integer.parseInt(deez,2);
			char lets = (char)nunz;
			outLine = outLine + lets;
			
		}
		System.out.println("Output of LFSR encryption algorith: " + outLine);
		System.out.println("Feel free to copy this to try and decrypt it as well.");
		FileWriter outFiller = new FileWriter(outputFile);
		BufferedWriter buffWriter = new BufferedWriter(outFiller);
		buffWriter.write(outLine);
		buffWriter.close();
		outFiller.close();
		
	}
	
	public char[] readTheFile() throws IOException {
		File inputFile = new File(inFilePath);
		FileReader fileReader = 
                new FileReader(inputFile);  
        BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

        String toDecrypt = bufferedReader.readLine();
        System.out.println("Current content of input file: " + toDecrypt);
        bufferedReader.close();
		char[] bytes = toDecrypt.toCharArray();
		
		StringBuilder bits = new StringBuilder(); 
		for(char b:bytes) {
			String dem = Integer.toBinaryString((int)b);
			
			String x = String.format("%8s",dem).replace(' ', '0');
		    bits.append(x);
		}
		fileReader.close();
		
		return bits.toString().toCharArray();
		
	}
	
	
	
}
