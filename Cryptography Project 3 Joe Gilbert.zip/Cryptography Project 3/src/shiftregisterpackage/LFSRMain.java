package shiftregisterpackage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/*
 * Class that contains the main method.
 * Probably not as advanced as necessary, however it mostly works.
 * The program asks the user for the positions of the 2 feedback bits,
 * and instantiates an LFSR using that information.
 * 
 * Created by Joe Gilbert, 2018.
 */
class LFSRMain {
	
	public static void main(String[] args) throws IOException {
		Scanner userInput = new Scanner(System.in);
		
		
		LFSRFileWriter lWriter = new LFSRFileWriter("Joe");
		//char[] arrayToDecrypt = lWriter.readTheFile();
		char[] arrayToDecrypt = lWriter.readTheFile();
		
		
		
		boolean[] bitWise = new boolean[arrayToDecrypt.length];
		for (int i = 0; i < bitWise.length ; i++) {
    		
			if (arrayToDecrypt[i] == '1') {
				bitWise[i] = true;
			}
			else if (arrayToDecrypt[i] == '0') {
				bitWise[i] = false;
			}
			
		}
		List<Integer> feedBackBitList = new ArrayList<Integer>();
		List<Integer> feedBackValidList = new ArrayList<Integer>();
		
		
		int inputLenForLFSR = 8;
		
		
		System.out.println("Enter the feedback bits: ");
				for (int i = 0; i < 2; i++) {
					int feedbackBit = Integer.parseInt(userInput.nextLine());
					while (feedbackBit > inputLenForLFSR-1 || feedbackBit < 0) {
						System.out.println("Invalid feedback bit, "
								+ "must be between 0 and "+(inputLenForLFSR));
						feedbackBit = Integer.parseInt(userInput.nextLine());
						
						
					}
					feedBackBitList.add(feedbackBit);
				}
				Collections.sort(feedBackBitList);
		
		
		ShiftRegister LFSR = new ShiftRegister(feedBackBitList,inputLenForLFSR,bitWise);
		boolean[] binSeed = LFSR.charToBoolean((LFSR.seed).toCharArray());
		LFSR.initializer();
		boolean[] bitKey = LFSR.generateKey(bitWise.length, binSeed);
		
		boolean[] finallyEncrypted = LFSR.encryptInput(bitKey, bitWise);
		
		char[] fullyEncrypted = LFSR.boolToChar(finallyEncrypted);
		
		lWriter.writeToTheFile(fullyEncrypted);
		
		
		userInput.close();
		
	}

}
